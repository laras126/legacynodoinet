import pygame
from pygame.locals import *
import ColorSprites, ButtonSprite, FoofaSprite, FattySprite
from ColorVars import *
	
#######################################################
#######################################################
# Some methods

def convertTimeFormat(not_seconds):
	' ' ' Assume not_seconds is not negative ' ' '
	not_hours = not_seconds / 4000
	not_seconds = not_seconds % 4000
	not_minutes = not_seconds / 40
	not_seconds = not_seconds % 40
	if not_seconds <= 9:
		not_seconds = "0" + str(not_seconds)
	else:
		not_seconds = str(not_seconds)
	if not_minutes <= 9:
		not_minutes = "0" + str(not_minutes)
	else:
		not_minutes = str(not_minutes)
	if not_hours <= 9:
		not_hours = "0" + str(not_hours)
	else:
		not_hours = str(not_hours)
	return not_hours + " : " + not_minutes

def myquit():
	pygame.quit()
	sys.exit(0)
	
#######################################################
#######################################################
# Handle events

def check_inputs(events, screen_id):
		
	if screen_id == 0:
	
		# Event handling for horn screen
		for event in events:
		
			# Method to quit
			if event.type == pygame.QUIT:
				myquit()
				
			elif event.type == KEYDOWN:
				if event.key == K_ESCAPE:
					myquit()

			elif event.type == MOUSEBUTTONDOWN:
				mouse_x, mouse_y = pygame.mouse.get_pos()
				splash.clicked_on(mouse_x, mouse_y) # Arrow goes to Fase screen
	
	if screen_id == 1:
	
		# Event handling for horn screen
		for event in events:
		
			# Method to quit
			if event.type == pygame.QUIT:
				myquit()
				
			elif event.type == KEYDOWN:
				if event.key == K_ESCAPE:
					myquit()
							
			elif event.type == MOUSEBUTTONDOWN:
				mouse_x, mouse_y = pygame.mouse.get_pos()
				info_btn.clicked_on(mouse_x, mouse_y) # Arrow goes to Fase screen
				#test.clicked_on(mouse_x, mouse_y) --  a shortcut to other screens if needed

	# Event handling for color screen
	elif screen_id == 2:
		
		# Method to quit
		for event in events:
			if event.type == pygame.QUIT:
				myquit()
			elif event.type == KEYDOWN:
				if event.key == K_ESCAPE:
					myquit()

			# Mouse button events	
			elif event.type == MOUSEBUTTONDOWN:
				mouse_x, mouse_y = pygame.mouse.get_pos()
				arrow.clicked_on(mouse_x, mouse_y) 
				for s in sliders: # Acitvate a slider
					s.clicked_on(mouse_x, mouse_y)	
			
				# Increase the sliders	
				if sliders[0].active == True: # the litegold box was clicked
					cc_box.increase_a()
					increment.play()
				elif sliders[1].active == True: # the midlitegold box was clicked
					cc_box.increase_b()
					increment.play()
				elif sliders[2].active == True: # the middarkgold box was clicked
					cc_box.increase_c()
					increment.play()
				elif sliders[3].active == True: # the darkgold box was clicked
					cc_box.increase_d()
					increment.play()	
				
			elif event.type == MOUSEBUTTONUP:
				mouse_x, mouse_y = pygame.mouse.get_pos()
				for s in sliders: # Acitvate a slider
					s.clicked_on(mouse_x, mouse_y)	
					
				# Increase the sliders	
				if sliders[0].active == True: # the litegold box was clicked
					cc_box.increase_a()
					increment.play()
				elif sliders[1].active == True: # the midlitegold box was clicked
					cc_box.increase_b()
					increment.play()
				elif sliders[2].active == True: # the middarkgold box was clicked
					cc_box.increase_c()
					increment.play()
				elif sliders[3].active == True: # the darkgold box was clicked
					cc_box.increase_d()	
					increment.play()
				
	# Event handling for game screen				
	elif screen_id == 3:

		# Method to quit
		for event in events:
			if event.type == pygame.QUIT:
				myquit()
			elif event.type == KEYDOWN:
				if event.key == K_ESCAPE:
					myquit()
					
			elif event.type == MOUSEBUTTONDOWN:
				mouse_x, mouse_y = pygame.mouse.get_pos()
				play_btn.clicked_on(mouse_x, mouse_y)  
					
	elif screen_id == 4:
	
		# Method to quit
		for event in events:
			if event.type == pygame.QUIT:
				myquit()
			elif event.type == KEYDOWN:
				if event.key == K_ESCAPE:
					myquit()
										
				# Move Fatty with the arrow keys	
				elif event.key == K_RIGHT:
					fatty.right()
					fatty.flipped = False
				elif event.key == K_LEFT:
					fatty.left()			
					fatty.flipped = False	
				elif event.key == K_UP:
					fatty.up()
				elif event.key == K_DOWN:
					fatty.down()	
					
				# Pause Fatty with spacebar		
				elif event.key == K_SPACE:
					fatty.pause()
					print "^^^^^^^^^^^^"
					print "FATTY PAUSED"
			elif event.type == KEYUP:
				if event.key == 32:
					fatty.pause()
					print "FATTY UNPAUSED"
					print "vvvvvvvvvvvv"
				if event.key == K_RIGHT:
					fatty.flipped = True
				if event.key == K_LEFT:
					fatty.flipped = True
					
	elif screen_id == 5:
		
		# And another method to quit
		for event in events:
			if event.type == pygame.QUIT:
				myquit()
			elif event.type == KEYDOWN:
				if event.key == K_ESCAPE:
					myquit()
					
			elif event.type == MOUSEBUTTONDOWN:
				mouse_x, mouse_y = pygame.mouse.get_pos()
				arrow_2.clicked_on(mouse_x, mouse_y) 
				yay.clicked_on(mouse_x, mouse_y) 
				nay.clicked_on(mouse_x, mouse_y) 
				
	elif screen_id == 6:
		for event in events:
			if event.type == pygame.QUIT:
				myquit()
			elif event.type == KEYDOWN:
				if event.key == K_ESCAPE:
					myquit()
					
			elif event.type == MOUSEBUTTONDOWN:
				mouse_x, mouse_y = pygame.mouse.get_pos()
				futtled_screen.clicked_on(mouse_x, mouse_y) 
									
#######################################################
#######################################################
# Instantiate some sprites, define some constants
	
if __name__ == "__main__":
	
	# Basics
	FPS = 40
	SCREEN_WIDTH = 700
	SCREEN_HEIGHT = 500
	
	# Text locations
	FASE_LOCATION = (30, 350)
	COUNTER_LOCATION = (20, 30)
	CREATECOLOR_LOCATION = (30, 30)
	
	# Some Very Important Vars
	screen_id = 0
	fase = 1	
	horn = 0
	futtles = 0
				
	# More basics			
	pygame.init()
	window = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), 0, 32)
	screen = pygame.display.get_surface()
	myfont = pygame.font.Font("images/NODOIRG_.TTF", 32) 
	myfont_sml = pygame.font.Font("images/NODOIRG_.TTF", 25) 
	
	# Here is some text
	createcolor_text = myfont.render("Create the Color!", 1, (0, 0, 0))
	ccbox_text = myfont.render (str(a) + " : " + str(b) + " : " + str(c) + " : " + str(d), 1, (0, 0, 0))
	getcc_text = myfont.render (str(a) + " : " + str(b) + " : " + str(c) + " : " + str(d), 1, (0, 0, 0))
	
	# Define some sliders
	slider_a = ColorSprites.Slider(screen, litegold, 35, 230, 400, 355, "litegold")
	slider_b = ColorSprites.Slider(screen, midlitegold, 35, 230, 460, 355, "midlitegold")
	slider_c = ColorSprites.Slider(screen, middarkgold, 35, 230, 520, 355, "middarkgold")
	slider_d = ColorSprites.Slider(screen, darkgold, 35, 230, 580, 355, "darkgold")
	cc_bkgd = ColorSprites.Slider(screen, white, 170, 500, 0, 500, "cc bkgd")
	
	# Instantiate the sliders
	sliders = [slider_a, slider_b, slider_c, slider_d]
	
	# Instantiate custom color boxes
	cc_box = ColorSprites.CustomColorBox(screen, [230, 230], [90, 355]) #Box for color screen
	cc_box_2 = ColorSprites.CustomColorBox(screen, [100, 100], [40, 210])
	get_cc = ColorSprites.GetColorBox(screen, [100, 100], [40, 360])
	cc_futtled = ColorSprites.CustomColorBox(screen, [100, 100], [200, 150])
	fcc_futtled = ColorSprites.GetColorBox(screen, [100, 100], [400, 150])
	
	# Instantiate some buttons	
	splash = ButtonSprite.ButtonSprite(screen, "images/splash.png", 0, 0, "entered") 
	arrow = ButtonSprite.ButtonSprite(screen, "images/arrow.png", 595, 410, "arrow to game") 
	play_btn = ButtonSprite.ButtonSprite(screen, "images/begin.gif", 35, 420, "play button") 
	arrow_2 = ButtonSprite.ButtonSprite(screen, "images/arrow.png", 595, 410, "new fase")
	info_btn = ButtonSprite.ButtonSprite(screen, "images/arrow.png", 595, 410, "go to color")
	yay = ButtonSprite.ButtonSprite(screen, "images/yay.png", 450, 240, "yay")
	nay = ButtonSprite.ButtonSprite(screen, "images/nay.png", 450, 290, "nay")
	test = ButtonSprite.ButtonSprite(screen, "images/begin.gif", 35, 420, "test button") 
	futtled_screen = ButtonSprite.ButtonSprite(screen, "images/futtled.png", 0, 0, "futtle screen") 
	
	# Instantiate the fatty
	fatty = FattySprite.FattySprite(screen, "images/running-fatt.gif", "images/blu_wave.gif", 700, 100, 2, 2, "its a fatty") 
	
	# A sound
	increment = pygame.mixer.Sound("sound/increment.wav")
	
	# Instantiate some fooling foofa
	lte_spy_lg = FoofaSprite.FoofaSprite(screen, "images/lte_spy_lg.gif", "sound/increment.wav", 500, 300)
	mdrk_mspy_lg = FoofaSprite.FoofaSprite(screen, "images/mdrk_mspy_lg.gif", "sound/increment.wav", 240, 350)
	drk_mdns_msml = FoofaSprite.FoofaSprite(screen, "images/drk_mdns_msml.gif", "sound/increment.wav", 200, 200)
	lte_dns_msml = FoofaSprite.FoofaSprite(screen, "images/lte_dns_msml.gif", "sound/increment.wav", 230, 40)
	mdrk_spy_msml = FoofaSprite.FoofaSprite(screen, "images/mdrk_spy_msml.gif", "sound/increment.wav", 400, 150)
	mlte_dns_sml = FoofaSprite.FoofaSprite(screen, "images/mlte_dns_sml.gif", "sound/increment.wav", 600, 60)
	
	foofa = [lte_spy_lg, mdrk_mspy_lg, drk_mdns_msml, lte_dns_msml, mdrk_spy_msml, mlte_dns_sml]


#######################################################
#######################################################
# Giganitc Game Loop	

while True:

	clock = pygame.time.Clock()
	clock.tick(40)
	screen.fill((255, 255, 255))
	pygame.display.set_caption('NODOI 2:1')
	
	if screen_id == 0:
		check_inputs(pygame.event.get(), screen_id)
		splash.draw()
		
		if splash.clicked == True:
			screen_id += 1
		
	elif screen_id == 1:
		check_inputs(pygame.event.get(), screen_id)
		instructions = pygame.image.load("images/instructions.png")
		screen.blit(instructions, (0,0))
		info_btn.draw()
		#test.draw() -- the shortcut
		
		if info_btn.clicked == True:		
			screen_id += 1
		#if test.clicked == True:
		#	screen_id = 6

				
	elif screen_id == 2:

		# Get inputs
		check_inputs(pygame.event.get(), screen_id)
		
		# Load text images
		create_text = pygame.image.load("images/create_text.png")
		tofase_text = pygame.image.load("images/tofase_text.png")
		# Put everything onto the screen
		screen.fill((255, 255, 255))
		screen.blit(create_text, (100, 40))
		screen.blit(tofase_text, (350, 390))
		
	
		# Draw arrow and sliders
		cc_box.draw()
		for s in sliders:
			s.draw()
			s.update()
		arrow.draw()

		# Arrow to change screens and set Fase (input not_seconds)
		if arrow.clicked == True:
			screen_id += 1
			print "....................."
			not_seconds = int(raw_input("How long for this Fase?? ")) * 40 # 4000 for not_minutes
			print "....................."
			global counter	
			counter = not_seconds
						
	elif screen_id == 3:
	
		arrow.clicked = False

		# Get inputs
		check_inputs(pygame.event.get(), screen_id)
		# Load nerescape, set caption
		nerescape = pygame.image.load("images/nerescape.png").convert_alpha()
		# Set fonts and text sizes, render text
		myfont_counter = pygame.font.Font("images/NODOIRG_.TTF", 35) 	
		counter_text = myfont_counter.render(str(convertTimeFormat(counter)), 1, (0, 0, 0))		
	
		# Draw everything
		screen.blit(nerescape, (0, 0))
		cc_bkgd.draw()
		cc_box_2.draw()
		get_cc.draw()
		play_btn.draw()
		for f in foofa:
			f.draw()
		screen.blit(counter_text, COUNTER_LOCATION) 
					
		# Press button to start the Fase/ release Fatty
		if play_btn.clicked == True:
			screen_id += 1
			
	elif screen_id == 4:
	
		# Get inputs
		check_inputs(pygame.event.get(), screen_id)
		# Load nerescape, set caption
		nerescape = pygame.image.load("images/nerescape.png").convert_alpha()
		# Set fonts and text sizes, render text
		myfont_fase = pygame.font.Font("images/NODOIRG_.TTF", 20) 
		myfont_counter = pygame.font.Font("images/NODOIRG_.TTF", 35) 	
		counter_text = myfont_counter.render(str(convertTimeFormat(counter)), 1, (0, 0, 0))		
		begun = pygame.image.load("images/begun.gif")
	
		# Draw everything
		screen.blit(nerescape, (0, 0))
		for f in foofa:
			f.draw()
		fatty.draw()
		fatty.update()
		cc_bkgd.draw()
		cc_box_2.draw()
		get_cc.draw()
		#begun_btn.draw()
		screen.blit(counter_text, COUNTER_LOCATION) 
		screen.blit(begun, (35, 420))

		counter -= 1 	
		
		# COLLISION
		for f in foofa:
			if pygame.sprite.collide_rect(f, fatty) == True: # On collision, play sound and increment
				f.sound.play()
				if something % 4 == nothing % 4: 
					horn += 1
					print "INCREMENTING ::: " + str(horn)  
		
		# Increase appropriate slider and check for futtling
 		if pygame.sprite.collide_rect(lte_spy_lg, fatty) == True:
			get_cc.increase_fa()
			if get_cc.color == cc_box.color:
				screen_id = 6
				futtles += 1
				horn += 400
				print "(((((((((((())))))))))))"
				print " FUTTLED ::: lte_spy_lg"
				print " (((((((((()))))))))))"
			
		if pygame.sprite.collide_rect(mdrk_mspy_lg, fatty) == True:
			get_cc.increase_fc()
			if get_cc.color == cc_box.color:
				screen_id = 6
				futtles += 1
				horn += 400
				print "(((((((((((())))))))))))"
				print "FUTTLED ::: mdrk_mspy_lg"
				print " (((((((((()))))))))))"

		if pygame.sprite.collide_rect(drk_mdns_msml, fatty) == True:
			get_cc.increase_fd()
			if get_cc.color == cc_box.color:
				screen_id = 6
				futtles += 1
				horn += 400
				print "(((((((((((())))))))))))"
				print "FUTTLED ::: drk_mdns_msml"
				print " (((((((((()))))))))))"

		if pygame.sprite.collide_rect(lte_dns_msml, fatty) == True:
			get_cc.increase_fa()			
			if get_cc.color == cc_box.color:
				screen_id = 6
				futtles += 1
				horn += 400
				print "(((((((((((())))))))))))"
				print "FUTTLED ::: lte_dns_msml"
				print " (((((((((()))))))))))"
		
		if pygame.sprite.collide_rect(mdrk_spy_msml, fatty) == True:
			get_cc.increase_fc()
			if get_cc.color == cc_box.color:
				screen_id = 6
				futtles += 1
				horn += 400
				print "(((((((((((())))))))))))"
				print "FUTTLED ::: mdrk_spy_msml"
				print " (((((((((()))))))))))"
		if pygame.sprite.collide_rect(mlte_dns_sml, fatty) == True:
			get_cc.increase_fb()
			if get_cc.color == cc_box.color:
				screen_id = 6
				futtles += 1
				horn += 400
				print "(((((((((((())))))))))))"
				print "FUTTLED ::: mlte_dns_sml"
				print " (((((((((()))))))))))"
					
		# When counter is 0, print a sum of the Fase and go to fase end screen
		if counter < 0:
			print "#############"
			print "#############"
			print "fase number: " + str(fase)
			print "fase duration: " + str(convertTimeFormat(not_seconds))
			print "increments: " + str(horn)
			print "futtles: " + str(futtles)
			print "#############"
			print "#############"
			screen_id += 1
			fase += 1
			
	elif screen_id == 5:
		# Get inputs
		check_inputs(pygame.event.get(), screen_id)
		
		########################################
		#**************************************#
		# Params for Levels and corresponding screens
		if horn <= 400 and horn < 444:
			level = 1
			level_1 = pygame.image.load("images/horn1.png")
			screen.blit(level_1, (0, 0))
		elif horn >= 444 and horn < 844:
			level = 2
			level_2 = pygame.image.load("images/horn2.png")
			screen.blit(level_2, (0, 0))
		elif horn >= 844 and horn < 1444:
			level = 3
			level_3 = pygame.image.load("images/horn3.png")
			screen.blit(level_3, (0, 0))
		elif horn >= 1444 and horn < 4444:
			level = 4
			level_4 = pygame.image.load("images/horn4.png")
		 	screen.blit(level_4, (0, 0))
		if horn >= 4444:
			level = "FULL"
			full_horn = pygame.image.load("images/fullhorn.png")
			screen.blit(full_horn, (0, 0))
			
			# If horn is full, you have the option to empty is
			yay.draw()
			nay.draw()
			
			if nay.clicked == True:
				myquit()
			if yay.clicked == True:
				play_btn.clicked = False
				splash.clicked = False
				info_btn.clicked = False
				arrow.clicked = False
				arrow_2.clicked = False
				cc_box.refresh()
				get_cc.refresh()
				fatty.refresh()	
				yay.clicked = False
				screen_id = 0 
				
		arrow_2.draw()
	
		# Back to color screen, refresh everything	
		if arrow_2.clicked == True:	
			print "::::level " + str(level) + ":::: "
			play_btn.clicked = False
			splash.clicked = False
			info_btn.clicked = False
			arrow.clicked = False
			arrow_2.clicked = False
			cc_box.refresh()
			get_cc.refresh()
			fatty.refresh()	
			screen_id = 2
			
	# Futtled screen		
	elif screen_id == 6:
		check_inputs(pygame.event.get(), screen_id)
		futtled_screen.draw()
		cc_futtled.draw()
		fcc_futtled.draw()
		if futtled_screen.clicked == True:
			screen_id = 4
			play_btn.clicked = True
			splash.clicked = True
			info_btn.clicked = True
			arrow.clicked = True
			arrow_2.clicked = False
			futtled_screen.clicked = False
	
	pygame.display.flip()

	
