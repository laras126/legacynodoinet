import pygame, os, sys
from pygame.locals import *

class FoofaSprite(pygame.sprite.Sprite):
	' ' ' Foofa equivalent to sliders ' ' '
	
	def load_image(self, image_name): 
		' ' ' Properly load the image ' ' '
		try:
			image = pygame.image.load(image_name)
		except pygame.error, message:
			print "Cannot load image: " + image_name
			raise SystemExit, message
		return image.convert_alpha()
		
	def __init__(self, screen, first_f, sound, init_x, init_y): #second_f, third_f, fourth_f -- add these later
		' ' ' Set the sprite parameters ' ' ' 
		
		pygame.sprite.Sprite.__init__(self) #call Sprite intializer
		self.screen = screen
		
		# Load images into sprite
		self.first_f = self.load_image(first_f)
		#self.second_f = self.load_image(second_f)
		#self.third = self.load_image(third_f) -- to be added later
		#self.fourth = self.load_image(fourth_f)
		
		# Set rect attribute, get image's width and height
		self.rect = self.first_f.get_rect()
		self.image_w, self.image_h = self.first_f.get_size()
		
		self.sound = pygame.mixer.Sound(sound)
		
		# Set the (x, y) and rect
		self.x = init_x
		self.y = init_y
		
		# Updated by Ming Chow on 8/15/2010
		self.rect.move(self.x, self.y)
		self.rect.topleft = (self.x, self.y)
		self.rect.bottomright = (self.x + self.image_w, self.y + self.image_h)
		
		# Has the fatty intersected with this mound?
		self.intersected = False
	
	def draw(self):
		' ' ' Draw sprite onto screen ' ' '
		#if self.intersected == False: -- also add later
		self.screen.blit(self.first_f, (self.x, self.y))
		
		
		#if self.intersected == True:
		#self.screen.blit(self.second_f, (self.x, self.y))
		#if self.intersected == 3: --- add later with the others
		#	self.screen.blit(self.third_f, (self.x, self.y))
		#if self.intersected == 4:
		#	self.screen.blit(self.fourth_f, (self.x, self.y))
