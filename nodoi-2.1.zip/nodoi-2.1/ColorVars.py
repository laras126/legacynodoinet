
# Colors, total
trh_background = (176, 23, 31)
litegold = (232, 209, 82)
midlitegold = (205, 173, 0)
middarkgold = (153, 102, 0)
darkgold = (102, 51, 0)
white = (255, 255, 255)
black = (0, 0, 0)

# Colors broken down - for customcolor calculation
r1 = 232 ## Reds
r2 = 205
r3 = 153
r4 = 102
g1 = 209 ## Greens
g2 = 173
g3 = 102
g4 = 51
b1 = 82 ## Blues
b2 = 0
b3 = 0
b4 = 0
# for foofa
fr1 = 232 ## Reds
fr2 = 205
fr3 = 153
fr4 = 102
fg1 = 209 ## Greens
fg2 = 173
fg3 = 102
fg4 = 51
fb1 = 82 ## Blues
fb2 = 0
fb3 = 0
fb4 = 0


# Starting customcolor values
a = 1
b = 1
c = 1
d = 1
# for foofa
fa = 1
fb = 1
fc = 1
fd = 1

# Not useful as of yet		
nothing = (a + b + c + d)
something = (fa + fb +fc + fd)
E = (something + nothing) / 4 
