import pygame
from pygame.locals import *
from ColorVars import *

class Slider(pygame.sprite.Sprite):

	def __init__(self, screen, color, width, height, x, y, label):
		' ' ' Sprite class for sliders ' ' '
		pygame.sprite.Sprite.__init__(self)
		self.screen = screen
		self.image = pygame.Surface((width, height))
		self.image.fill(color)
		self.rect = self.image.get_rect()
		self.width = width
		self.height = height
		self.x = x
		self.y = y
		self.label = label
		self.rect.bottomleft = (x, y)
		self.image_w, self.image_h = self.image.get_size()
		self.active = False

	def clicked_on(self, _a, _b):
		if (self.rect.collidepoint(_a, _b)):
			self.active = True
			self.screen.blit(self.image, self.rect)
		else:
			self.active = False
				
	def draw(self):
		self.screen.blit(self.image, self.rect)

	def update(self): ### this is meant to make the slider get taller, doesn't work
		self.rect.bottomleft = (self.x, self.y)
		self.image_w, self.image_h = self.image.get_size()
		self.screen.blit(self.image, self.rect)
		
########################################		
########################################
		
class CustomColorBox(pygame.sprite.Sprite):

	def __init__(self, screen, size, initial_pos):
		' ' ' Class for custom color box ' ' '
		pygame.sprite.Sprite.__init__(self)
		self.screen = screen
		
		# Algorithms for customcolor
		self.color = ((r1*a + r2*b + r3*c + r4*d) / (a+b+c+d), 
		(g1*a + g2*b + g3*c + g4*d) / (a+b+c+d), 
		(b1*a + b2*b + b3*c + b4*d) / (a+b+c+d))
		
		self.image = pygame.Surface(size)
		self.image.fill(self.color)
		self.rect = self.image.get_rect()
		self.rect.bottomleft = initial_pos
		
	def draw(self):
		self.color = ((r1*a + r2*b + r3*c + r4*d) / (a+b+c+d), 
		(g1*a + g2*b + g3*c + g4*d) / (a+b+c+d), 
		(b1*a + b2*b + b3*c + b4*d) / (a+b+c+d))
		self.image.fill(self.color)
		self.screen.blit(self.image, self.rect)
				
	def increase_a(self): # Increase by 1 part a (litegold) 
		global a
		a += 1
		print a, b, c, d 
	def increase_b(self): # Increase by 1 part b (midlitegold) 
		global b
		b += 1 
		print a, b, c, d
	def increase_c(self): # Increase by 1 part c (middarkgold) 
		global c
		c += 1
		print a, b, c, d
	def increase_d(self): # Increase by 1 part d (darkgold) 
		global d
		d += 1 
		print a, b, c, d

	def refresh(self):
		global a
		a = 1
		global b
		b = 1
		global c
		c = 1
		global d
		d = 1
		
########################################		
########################################
	
class GetColorBox(pygame.sprite.Sprite):

	def __init__(self, screen, size, initial_pos):
		' ' ' Class for custom color box ' ' '
		pygame.sprite.Sprite.__init__(self)
		# Create and fill image to be displayed
		self.screen = screen
		
		# Algorithms for customcolor
		self.color = ((r1*a + r2*b + r3*c + r4*d) / (a+b+c+d), 
		(g1*a + g2*b + g3*c + g4*d) / (a+b+c+d), 
		(b1*a + b2*b + b3*c + b4*d) / (a+b+c+d))
		
		self.image = pygame.Surface(size)
		self.image.fill(self.color)
		self.rect = self.image.get_rect()
		self.rect.bottomleft = initial_pos
		
	def draw(self):
		self.color = ((fr1*fa + fr2*fb + fr3*fc + fr4*fd) / (fa+fb+fc+fd), 
		(fg1*fa + fg2*fb + fg3*fc + fg4*fd) / (fa+fb+fc+fd), 
		(fb1*fa + fb2*fb + fb3*fc + fb4*fd) / (fa+fb+fc+fd))
		self.image.fill(self.color)
		self.screen.blit(self.image, self.rect)
				
	def increase_fa(self): # Increase by 1 part a (litegold) 
		global fa
		fa += 1
		print fa, fb, fc, fd, " - foofa"
		print a, b, c, d
	def increase_fb(self): # Increase by 1 part b (midlitegold) 
		global fb
		fb += 1 
		print fa, fb, fc, fd, " - foofa"
		print a, b, c, d
	def increase_fc(self): # Increase by 1 part c (middarkgold) 
		global fc 
		fc += 1
		print fa, fb, fc, fd, " - foofa"
		print a, b, c, d
	def increase_fd(self): # Increase by 1 part d (darkgold) 
		global fd 
		fd += 1
		print fa, fb, fc, fd, " - foofa"
		print a, b, c, d
		
	def refresh(self):
		global fa
		fa = 1
		global fb
		fb = 1
		global fc
		fc = 1
		global fd
		fd = 1