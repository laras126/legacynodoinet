import pygame, sys
from pygame.locals import *

# fatty bounces off the walls
# while bouncing, moves by increments of 30 with arrow keys
# holding space bar pauses fatty

class FattySprite(pygame.sprite.Sprite):
	' ' ' A container for a fatty ' ' '
	
	def load_image(self, image_name):
		''' The proper way to load an image '''
		try:
			image = pygame.image.load(image_name)
		except pygame.error, message:
			print "Cannot load image: " + image_name
			raise SystemExit, message
		return image.convert_alpha()

	def __init__(self, screen, fir_img, sec_img, init_x, init_y, init_x_speed, init_y_speed, label):
	
		self.screen = screen	
		
		self.fir_img = self.load_image(fir_img) # Load images
		self.sec_img = self.load_image(sec_img)
		
		self.rect = self.fir_img.get_rect()
		self.image_w, self.image_h = self.fir_img.get_size()
		
		self.x = init_x # Set the x and y
		self.y = init_y
		self.label = label
		
		self.dx = init_x_speed # Set the default speed
		self.dy = init_y_speed
		
		self.feeding = False # controls the switch to feeding image
		self.pressed = False # enables spacebar pause
		self.flipped = False
		
		self.rect.move(self.x, self.y)
		self.rect.topleft = (self.x, self.y)
		self.rect.bottomright = (self.x + self.image_w, self.y + self.image_h)
		
	def pause(self): # Pause fatty
		if (self.pressed == True):
			self.pressed = False
		else:
			self.pressed = True
		
	def flip(self):
		
		pass
		
	def right(self):
		if self.x >= self.screen.get_size()[0]:
			self.x -= 50
			self.flipped = True
		else:
			self.x += 30
		
	def left(self):
		if self.x <= 0:
			self.x += 50
			self.flipped = False
		else:
			self.x -= 30
	
	def down(self):
		if self.y >= self.screen.get_size()[0]:
			self.y -= 50
		else:
			self.y += 30
		
	def up(self):
		if self.y <= 0:
			self.y += 50
		else:
			self.y -= 30
		
	def draw(self): # Draw first image if feeding, second if not feeding
		draw_pos = self.fir_img.get_rect().move(self.x - self.image_w / 2, self.y - self.image_h / 2)
		next_pos = self.sec_img.get_rect().move(self.x - self.image_w / 2, self.y - self.image_h / 2)	
		if self.feeding == False:		
			self.screen.blit(self.fir_img, draw_pos)
		else:
			self.screen.blit(self.sec_img, next_pos)
		if self.flipped == True:
			self.fir_img = pygame.transform.flip(self.fir_img, 1, 0)
			self.flipped = False
						
	def update(self):
		if self.pressed == False:	
			' ' ' Fatty bounces off of walls ' ' '
			if ((self.x + self.dx) <= 170):
				self.dx = self.dx * -1
			if ((self.x + self.dx) >= self.screen.get_size()[0]):
				self.dx = self.dx * -1
			if ((self.y + self.dy) <= 0):
				self.dy = self.dy * -1
			if ((self.y + self.dy) >= self.screen.get_size()[1]):
				self.dy = self.dy * -1
			self.x = self.x + self.dx
			self.y = self.y + self.dy

		self.rect.move(self.x, self.y)
		self.rect.topleft = (self.x, self.y)
		self.rect.bottomright = (self.x + self.image_w, self.y + self.image_h)
		
	def refresh(self):
		self.x = 700
		self.y = 100
		self.dx = 3
		self.dx = 3
		self.pressed = False
		