import pygame, sys, os
from pygame.locals import *

class ButtonSprite(pygame.sprite.Sprite):
	' ' ' Sprite to contain the clickable arrow ' ' ' 

	def load_image(self, image_name):
		' ' ' The proper way to load an image ' ' '
		try:
			image = pygame.image.load(image_name)
		except pygame.error, message:
			print "Cannot load image: "
			raise SystemExit, message
		return image.convert_alpha()
	
	def __init__(self, screen, img_file, x, y, label):
		self.screen = screen
		self.image = self.load_image(img_file)
		self.x = x
		self.y = y
		self.label = label
		self.rect = self.image.get_rect()
		self.image_w, self.image_h = self.image.get_size()
		self.clicked = False
		self.begin = False
		
	def clicked_on(self, _a, _b):
		if (_a >= self.x and _a <= self.x + self.image_w and _b >= self.y and _b <= self.y + self.image_h):
			self.clicked = True
			print "clicked " + self.label
	
	def switch_btn(self, _a, _b):
		self.begun = True
				
	def draw(self):
		self.screen.blit(self.image, (self.x, self.y))
		pass
		

